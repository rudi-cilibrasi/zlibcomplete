var searchData=
[
  ['gzipcompressor',['GZipCompressor',['../classzlibcomplete_1_1GZipCompressor.html#a5251e94e3a2b65a4a4bb82ad0b56abe6',1,'zlibcomplete::GZipCompressor']]],
  ['gzipdecompressor',['GZipDecompressor',['../classzlibcomplete_1_1GZipDecompressor.html#ac5dac4172de37b3352eed7d3da623e6a',1,'zlibcomplete::GZipDecompressor']]]
];
