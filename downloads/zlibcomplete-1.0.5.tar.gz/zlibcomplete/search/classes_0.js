var searchData=
[
  ['gzipcompressor',['GZipCompressor',['../classzlibcomplete_1_1GZipCompressor.html',1,'zlibcomplete']]],
  ['gzipdecompressor',['GZipDecompressor',['../classzlibcomplete_1_1GZipDecompressor.html',1,'zlibcomplete']]]
];
