var searchData=
[
  ['compress',['compress',['../classzlibcomplete_1_1GZipCompressor.html#a7b0f19e9b1c6341e401932ea601b07c4',1,'zlibcomplete::GZipCompressor::compress()'],['../classzlibcomplete_1_1ZLibCompressor.html#abbb2d285ae361239827770e7ed1f55b6',1,'zlibcomplete::ZLibCompressor::compress()']]]
];
